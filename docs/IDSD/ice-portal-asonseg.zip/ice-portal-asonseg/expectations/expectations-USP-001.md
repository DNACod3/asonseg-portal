# Expectations — USP-001: Auto-cadastro de Pessoa no portal (público)

**Origem:** AC-001-1 a AC-001-7 do PRD MVP Portal v0.3, ajustados e estendidos.

## 1. Cenários de sucesso testáveis

- **E-001:** WHEN o visitante submete nome, CPF formalmente válido, e-mail não usado por outra Pessoa, senha que satisfaz a política, CAPTCHA aprovado, ao menos um papel público escolhido e aceite explícito do termo da finalidade desse papel, the system SHALL persistir Pessoa + credencial + papel(éis) + consentimento(s) — com versão do termo, data e IP — em **transação única**, enviar e-mail de boas-vindas e gravar log de auditoria.

  *Ajuste do AC-001-1 e AC-001-6:* explicitada a atomicidade da operação Pessoa+credencial+papel+consentimento, e a versão do termo + IP na evidência de consentimento (ADR-0013).

- **E-002:** WHEN o cadastro conclui com sucesso, the system SHALL redirecionar o visitante para uma tela de **próximo passo específico do papel ativado** (ex.: cadastro de CV se papel candidato; cadastro de prestador PF se prestador). Não cair em home genérica.

  *Ajuste:* AC do PRD não exige tela de próximo passo específico; vem do cenário de sucesso operacional do intent.

- **E-003:** IF o e-mail informado já está em uso por outra Pessoa, THEN the system SHALL bloquear o cadastro com mensagem determinística informando o conflito de e-mail.

- **E-004:** IF o CPF informado já está em uso por outra Pessoa, THEN the system SHALL bloquear o cadastro com mensagem determinística informando o conflito de CPF (sem expor a Pessoa pré-existente).

- **E-005:** IF o CPF tem formato/dígito verificador inválido, THEN the system SHALL bloquear o cadastro antes de tocar persistência.

- **E-006:** WHERE dois submits chegam simultaneamente com o mesmo CPF (ou o mesmo e-mail), the system SHALL persistir uma única Pessoa e retornar **erro determinístico (HTTP 409 ou equivalente)** para o segundo submit — nunca 500, nunca duplicidade silenciosa.

  *Extensão dos AC-001-2/3:* explicita comportamento sob concorrência (toca F1 do intent).

- **E-007:** The system SHALL armazenar senhas com bcrypt (ou equivalente vigente em 2026) com cost factor suficiente para resistência adequada.
  ❓ Cost factor mínimo do bcrypt em 2026 a definir. (técnico)

## 2. Proibições (must-not)

- **P-001 (toca F1 — race condition):** O sistema NÃO PODE criar duas Pessoas com mesmo CPF nem duas Pessoas com mesmo e-mail, mesmo sob submits simultâneos. Equivalente operacional: unique constraint no banco + tratamento determinístico do conflito (409 no segundo submit, nunca 500, nunca persistência dupla).

- **P-002 (toca F2 — papel sem consentimento):** O sistema NÃO PODE ativar nenhum papel público antes do consentimento da finalidade correspondente estar persistido — versão do termo, data e IP. Nem por um milissegundo. Se a persistência do consentimento falhar, o papel não fica ativo e a Pessoa não fica criada.

- **P-003 (toca F3 — senha):** O sistema NÃO PODE armazenar senha em texto claro nem com algoritmo legado (MD5, SHA-1, ou qualquer hash sem salt). Nenhuma rota administrativa pode contornar essa regra.

- **P-004 (toca F4 — e-mail prematuro):** O sistema NÃO PODE enviar e-mail de boas-vindas antes da confirmação de persistência da Pessoa. Em caso de falha posterior, a Pessoa não pode existir e o e-mail não pode ter sido enviado.

- **P-005 (toca F5 — CAPTCHA bypass):** O sistema NÃO PODE aceitar submit de auto-cadastro sem validação de CAPTCHA aprovada — inclusive via chamada direta à API, sem passar pelo formulário web.

- **P-006 (toca F6 — log silencioso):** O sistema NÃO PODE deixar de gravar log de auditoria de um cadastro que persistiu Pessoa. Falha na auditoria invalida a transação ou dispara alerta operacional imediato; não fica silenciosa.

- **P-007 (toca F7 — marca de exceção):** O sistema NÃO PODE permitir que o fluxo público de auto-cadastro grave a marca "Pessoa sem documento — exceção" no cadastro. Essa marca só pode ser gravada pelo fluxo da AS via USP-002.

- **P-008:** O sistema NÃO PODE revelar, em mensagem de erro pública, a existência ou inexistência de uma Pessoa por meio de combinação de tentativas (ex.: enumeration via e-mail vs CPF retornando mensagens distintas que possibilitem inferência).

## 3. Limites

- **L-001 (Performance):** Tempo de resposta do submit ≤ 2s p95 (§6.1 do PRD).
- **L-002 (E-mail):** Boas-vindas entregue (no SMTP, não no inbox final) em ≤ 60s após confirmação da transação.
- **L-003 (Rate limiting):** Máximo N submissões de auto-cadastro por IP por janela de M minutos antes de exigir desafio adicional ou bloqueio temporário.
  ❓ N e M a definir conforme provedor CAPTCHA e tamanho de público. (técnico)
- **L-004 (Retenção):** Tentativas de cadastro falhas (auth_attempts ou registro equivalente) retidas por período suficiente para análise anti-bot.
  ❓ Janela específica a definir com base em ADR-0017 e LGPD. (dono do intent + técnico)
- **L-005 (Segurança):** TLS obrigatório em toda a operação (§6.3 do PRD).

## 4. Critérios de pronto, do ponto de vista do dono do intent

- **D-001:** Uma Pessoa real da comunidade (fora do time Bravi), em celular de baixo desempenho com conexão 4G modesta, conclui o auto-cadastro do início ao fim em < 3 minutos sem ajuda externa. Validado com ≥ 3 testes desse tipo, com no mínimo 1 papel público diferente em cada.

- **D-002:** Em janela de teste de carga sintética simulando 10 submits simultâneos com o mesmo CPF, **zero Pessoas duplicadas** e mensagem de erro determinística no segundo submit em diante. Mesmo teste repetido com mesmo e-mail.

- **D-003:** O painel pós-cadastro mostra próximo passo claro para o papel ativado (cadastro CV para candidato, cadastro prestador para prestador, etc.) — verificado por papel, por inspeção do sponsor.

- **D-004 (gate jurídico):** Antes desta USP ir para produção, **D-002 do PRD (termos por finalidade)** está concluído e os termos das finalidades dos quatro papéis públicos foram revisados e aprovados pelo jurídico/diretoria por escrito. Sem isso, esta USP **não vai para produção** mesmo que o código esteja pronto — ela viola ADR-0013 por padrão.

- **D-005 (gate operacional):** A AS consegue, em ensaio com voluntário, abrir a auditoria de uma Pessoa recém-cadastrada e ver os campos esperados (Pessoa, IP, versão do termo, data, papel ativado, consentimento).

- **D-006:** Em teste de bypass: tentativa de chamada direta à API de cadastro sem CAPTCHA é rejeitada com erro determinístico. Validado por engenheiro Bravi e por inspeção do log.
