# Intent — USP-033: Manifestar interesse em serviço

**Origem:** PRD v0.3 §5.2, USP-033.
**Dono do intent:** Coordenador da área Portal Empregabilidade.

## 1. Descrição

Pessoa autenticada clica em "entrar em contato" em um serviço ativo. Outcome: papel "cliente de serviço" é ativado automaticamente se ainda não estiver (papel mais leve — ADR-0011); manifestação é persistida; contato do prestador é revelado ao cliente; e-mail é enviado ao prestador avisando do interesse (USP-044). Reciprocidade do ADR-0017: ação afirmativa do cliente revela contato do prestador, e também identifica o cliente para o prestador (USP-035).

## 2. Restrições

- Pessoa precisa estar autenticada (USP-001).
- Serviço precisa estar ativo (USP-029 + USP-016 aprovou).
- Papel "cliente de serviço" é ativado automaticamente na primeira manifestação se ainda não ativo (AC-033-2, ADR-0011 — papel mais leve).
- Consentimento "contratação de serviço" (finalidade 4 do ADR-0013) precisa estar ativo — exibido na ativação automática do papel se for primeira vez.
- Múltiplas manifestações simultâneas em serviços diferentes permitidas (AC-033-3).
- Manifestação persiste + contato do prestador revelado ao cliente + e-mail ao prestador (AC-033-1, AC-031-3).

## 3. Cenários de fracasso (de resultado)

**F1. Ativação automática do papel cliente cria consentimento sem o cliente perceber.**
AC-033-2 ativa o papel "sem formulário adicional". Mas ADR-0013 exige consentimento explícito da finalidade 4 antes da ativação. Tensão real: cliente clica "entrar em contato" e o termo precisa aparecer — se for "modal rápido" e o cliente clicar OK sem ler, consentimento existe formalmente mas não materialmente.

❓ Modal de consentimento precisa ser exibido antes de revelar contato? Ou o consentimento é embutido no clique "entrar em contato"? (dono do intent — jurídico + DPO + designer) → D-001, D-002

**F2. Cliente clica "manifestar interesse" em N serviços para coletar contatos sem real intenção — funil de spam.**
Sem limite, cliente abre 20 serviços e manifesta interesse em todos para acumular contatos. Prestadores recebem e-mail e perdem tempo respondendo a cliente sem interesse real.

❓ Sistema impõe limite (ex.: máx N manifestações ativas / semana)? Prestador pode bloquear cliente? (dono do intent — coordenador)

**F3. Prestador recebe contato do cliente que manifestou interesse mas, ao tentar responder, descobre dados desatualizados.**
Cliente cadastrou-se com e-mail antigo; usa raramente. Prestador responde, e-mail não chega. Manifestação fica sem fechamento e prestador frustra-se com o portal.

❓ Fora do controle do sistema — gestão de e-mail do cliente. Sem ❓ adicional. (dono do intent)

**F4. Atomicidade falha: persistir manifestação + ativar papel + enviar e-mail + revelar contato.**
Cf. F5 do USP-025 — múltiplos efeitos colaterais em uma operação. Falha parcial deixa estado quebrado.

❓ (arquitetural-estrutural → vira ADR técnico) Política de transação/retry. Resolução técnica delegada ao Tech Lead.

**F5. Cliente cancela manifestação (USP-034) mas prestador já tem o contato.**
ADR-0017 não fala sobre revogar visibilidade após cancelamento (cf. F3 do USP-026). Prestador continua contatando cliente que cancelou.

❓ Cancelamento revoga visibilidade do contato no painel do prestador? (dono do intent — jurídico + coordenador)

## 4. Cenários de sucesso

**Nível operacional:**
- Pessoa autenticada abre detalhe de serviço → clica "entrar em contato" → (se for primeira vez) confirma consentimento finalidade 4 → papel cliente ativado → contato do prestador revelado → e-mail ao prestador.
- Cliente entra em contato externamente (telefone/WhatsApp) e contrata o serviço.
- Prestador vê manifestação em painel (USP-035) com nome do cliente, contato, data e serviço referenciado.

**Nível agregado:**
- **MP7** — número de manifestações de interesse. Métrica do funil de serviços.

## 5. Conexões

**USPs upstream:** USP-001 ou USP-006 (autenticação), USP-011 (papel cliente ativado automaticamente), USP-030/USP-031 (descobriu serviço), USP-043 (consentimento finalidade 4).

**USPs downstream:** USP-034 (cancelar), USP-035 (prestador vê), USP-044 (e-mail ao prestador).

**ADRs aplicáveis:** ADR-0011 (cliente é papel leve, ativação automática), ADR-0013 (consentimento finalidade 4), ADR-0017 (visibilidade recíproca).

**Métricas tocadas:** MP7 (manifestações).

**Riscos relacionados:** RP-003 (consentimento finalidade 4 precisa estar coberto pelo termo). Risco proposto: manifestação em massa para coletar contatos.

**Dependências:** D-002 (termo da finalidade 4).

**Q-abertas:** —
