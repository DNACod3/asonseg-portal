# Matriz de Conexões — MVP Portal Empregabilidade e Serviços (ASONSEG)

**Origem:** PRD `prd-asonseg-portal-mvp` v0.3 (22/05/2026)
**Status:** Esqueleto gerado pela skill `po-bravi-idsd`. Colunas técnicas (schemas, skills/runbooks, ADRs técnicos) serão preenchidas pela skill `architecture-planning` na sequência.
**Escopo:** apenas USPs do Release 1 (USP-001 a USP-044). ADRs 0002, 0003, 0004, 0005, 0006, 0007, 0009 aplicam-se ao Release 2 (Frente 4) e não aparecem aqui.

---

## Seção 1 — Índice compacto

| USP | Título | Épico | Prioridade |
|---|---|---|---|
| USP-001 | Auto-cadastro de Pessoa no portal (público) | 1 — Identidade, Acesso e Papéis | Must |
| USP-002 | Cadastro de Pessoa pela assistente social (situação extrema) | 1 — Identidade, Acesso e Papéis | Must |
| USP-003 | Reivindicar credencial de Pessoa pré-cadastrada | 1 — Identidade, Acesso e Papéis | Must |
| USP-004 | Login no portal | 1 — Identidade, Acesso e Papéis | Must |
| USP-005 | Recuperar senha esquecida | 1 — Identidade, Acesso e Papéis | Must |
| USP-006 | Ativar papel adicional na Pessoa autenticada | 1 — Identidade, Acesso e Papéis | Must |
| USP-007 | Inativar Pessoa (desligamento de voluntário ou pedido do titular) | 1 — Identidade, Acesso e Papéis | Must |
| USP-008 | Configurar permissões delegadas a voluntário no portal | 1 — Identidade, Acesso e Papéis | Must |
| USP-009 | Cadastro de candidato (papel) | 2 — Cadastros Públicos | Must |
| USP-010 | Cadastro de prestador de serviço (papel) | 2 — Cadastros Públicos | Must |
| USP-011 | Cadastro de cliente de serviço (papel) | 2 — Cadastros Públicos | Must |
| USP-012 | Cadastro de Empresa (pela Pessoa que se torna responsável) | 2 — Cadastros Públicos | Must |
| USP-013 | Adicionar responsável a uma Empresa | 3 — Gestão de Vínculos Pessoa-Empresa | Must |
| USP-014 | Remover responsável de uma Empresa | 3 — Gestão de Vínculos Pessoa-Empresa | Must |
| USP-015 | Editar dados da Empresa | 3 — Gestão de Vínculos Pessoa-Empresa | Must |
| USP-016 | Moderar rascunho (vaga, CV ou serviço) | 4 — Moderação de Conteúdo | Must |
| USP-017 | Validar Empresa na primeira vaga publicada | 4 — Moderação de Conteúdo | Must |
| USP-018 | Inativar conteúdo já publicado | 4 — Moderação de Conteúdo | Must |
| USP-019 | Sugerir nova categoria de serviço ou área de vaga | 4 — Moderação de Conteúdo | Should |
| USP-020 | Publicar vaga | 5 — Vagas | Must |
| USP-021 | Buscar vagas (pública) | 5 — Vagas | Must |
| USP-022 | Ver detalhe da vaga | 5 — Vagas | Must |
| USP-023 | Editar vaga (pausar, arquivar, renovar) | 5 — Vagas | Must |
| USP-024 | Expiração automática de vaga | 5 — Vagas | Must |
| USP-025 | Candidatar-se a uma vaga | 6 — Candidaturas e Busca de Candidatos | Must |
| USP-026 | Cancelar candidatura | 6 — Candidaturas e Busca de Candidatos | Must |
| USP-027 | Empresa ver lista de candidatos da vaga | 6 — Candidaturas e Busca de Candidatos | Must |
| USP-028 | Empresa buscar candidatos (busca ativa) | 6 — Candidaturas e Busca de Candidatos | Must |
| USP-029 | Publicar serviço | 7 — Serviços | Must |
| USP-030 | Buscar serviços (pública) | 7 — Serviços | Must |
| USP-031 | Ver detalhe do serviço | 7 — Serviços | Must |
| USP-032 | Editar serviço (pausar, arquivar) | 7 — Serviços | Must |
| USP-033 | Manifestar interesse em serviço | 8 — Manifestação de Interesse em Serviço | Must |
| USP-034 | Cancelar manifestação de interesse | 8 — Manifestação de Interesse em Serviço | Should |
| USP-035 | Prestador ver manifestações de interesse | 8 — Manifestação de Interesse em Serviço | Must |
| USP-036 | Cadastrar ficha socioeconômica da Pessoa | 9 — Ficha Social, Encaminhamento e Visão Consolidada | Must |
| USP-037 | Encaminhar Pessoa para vaga | 9 — Ficha Social, Encaminhamento e Visão Consolidada | Must |
| USP-038 | Registrar resultado do encaminhamento manualmente | 9 — Ficha Social, Encaminhamento e Visão Consolidada | Must |
| USP-039 | Visão consolidada da Pessoa | 9 — Ficha Social, Encaminhamento e Visão Consolidada | Must |
| USP-040 | Extração automática de CV via IA generativa | 10 — Extração de CV via IA Generativa | Must |
| USP-041 | Home pública com indicadores em tempo real | 11 — Indicadores e Relatórios | Must |
| USP-042 | Relatórios operacionais do Portal | 11 — Indicadores e Relatórios | Must |
| USP-043 | Consentimentos LGPD por finalidade | 12 — Conformidade LGPD (Consentimentos) | Must |
| USP-044 | Notificações por e-mail em eventos do portal | 13 — Notificações por E-mail | Must |

---

## Seção 2 — Cards de conexão por USP

### USP-001 — Auto-cadastro de Pessoa no portal (público)

- **Upstream:** USP-043 (consentimento por finalidade precisa estar persistido junto com o cadastro)
- **Downstream:** USP-004, USP-006, USP-009, USP-010, USP-011, USP-012, USP-013, USP-025, USP-033, USP-037 (e toda USP autenticada)
- **ADRs:** ADR-0010, ADR-0011, ADR-0013, ADR-0017
- **Métricas:** MP1, MP2, MP3 (vetor de entrada para qualquer papel público)
- **Riscos:** RP-003 (termos), RP-008 (indireto via USP-040 quando candidato anexar CV)
- **Deps/Q-abertas:** D-002 (termos), D-009 (CAPTCHA), QP-003

### USP-002 — Cadastro de Pessoa pela assistente social (situação extrema)

- **Upstream:** —
- **Downstream:** USP-003 (Pessoa pode reivindicar credencial), USP-036, USP-037, USP-039
- **ADRs:** ADR-0010, ADR-0011, ADR-0017
- **Métricas:** — (indireto via USP-037)
- **Riscos:** RP-002 (DPO — Pessoa sem credencial ainda gera dado pessoal)
- **Deps/Q-abertas:** D-001 (DPO), D-002 (termos — neste caso o termo é assinado fora do sistema)

### USP-003 — Reivindicar credencial de Pessoa pré-cadastrada

- **Upstream:** USP-002 (Pessoa precisa estar pré-cadastrada)
- **Downstream:** USP-004, USP-006, USP-043
- **ADRs:** ADR-0010, ADR-0011, ADR-0017
- **Métricas:** —
- **Riscos:** Risco proposto: sequestro de identidade por reivindicação falsa (mitigação no processo de verificação)
- **Deps/Q-abertas:** D-011 (meios de verificação), QP-001

### USP-004 — Login no portal

> O PRD lista USP-004 no índice do Épico 1 com prioridade Must, mas o corpo do PRD na §5.2 não detalha os ACs entre USP-003 e USP-005. Tratado aqui como "Login (e-mail + senha) com bloqueio temporário", coerente com §6.3 do PRD. ❓ Confirmar ACs explícitos no PRD ou tratar como gap. (dono do intent + Bravi PO)

- **Upstream:** USP-001 ou USP-003 (credencial existir)
- **Downstream:** todas as USPs autenticadas
- **ADRs:** ADR-0010
- **Métricas:** — (transversal)
- **Riscos:** RP-009 (rate limiting); risco proposto: brute-force e enumeração de e-mails
- **Deps/Q-abertas:** —

### USP-005 — Recuperar senha esquecida

- **Upstream:** USP-001 ou USP-003
- **Downstream:** USP-004
- **ADRs:** ADR-0010
- **Métricas:** —
- **Riscos:** Risco proposto: enumeração de e-mails (mitigado por AC-005-2 — mensagem genérica)
- **Deps/Q-abertas:** —

### USP-006 — Ativar papel adicional na Pessoa autenticada

- **Upstream:** USP-001 ou USP-002+USP-003 (Pessoa precisa existir), USP-043 (consentimento da finalidade do papel novo)
- **Downstream:** USP-009 (se papel = candidato), USP-010 (prestador), USP-011 (cliente), USP-012 (empresa-responsável)
- **ADRs:** ADR-0011, ADR-0013, ADR-0015 (a moderação do CONTEÚDO posterior é o gate, não o papel em si)
- **Métricas:** MP1, MP2, MP3 (entrada lateral em papéis adicionais)
- **Riscos:** RP-003 (termo da finalidade nova)
- **Deps/Q-abertas:** D-002

### USP-007 — Inativar Pessoa (desligamento de voluntário ou pedido do titular)

- **Upstream:** —
- **Downstream:** USP-004 (bloqueio de login), USP-008 (revogação de permissões delegadas), USP-014 (sucessão de responsável de Empresa)
- **ADRs:** ADR-0008 (estendido — retenção do histórico), ADR-0011
- **Métricas:** —
- **Riscos:** Risco proposto: inativar único responsável de Empresa quebra USP-014 (mitigado por AC-007-3)
- **Deps/Q-abertas:** D-001 (DPO precisa estar designado para autorizar inativação a pedido do titular)

### USP-008 — Configurar permissões delegadas a voluntário no portal

- **Upstream:** USP-001 (Pessoa existir como voluntário), USP-004
- **Downstream:** USP-016, USP-017, USP-018, USP-019, USP-037, USP-038, USP-003 (reivindicação delegável)
- **ADRs:** ADR-0001 (estendido — catálogo do Portal), ADR-0010
- **Métricas:** — (transversal — operacional)
- **Riscos:** RP-004 (carga de moderação — delegar a voluntários é o mecanismo de escala)
- **Deps/Q-abertas:** D-006 (catálogo final), QP-006

### USP-009 — Cadastro de candidato (papel)

- **Upstream:** USP-001 (ou USP-006), USP-043 (consentimento "candidatura a vagas"), USP-040 (extração de CV)
- **Downstream:** USP-016 (moderação do perfil), USP-025, USP-028, USP-037
- **ADRs:** ADR-0011, ADR-0013, ADR-0015, ADR-0017, ADR-0018
- **Métricas:** MP1
- **Riscos:** RP-003, RP-007 (CV ruim validado), RP-008 (LLM sem ZDR)
- **Deps/Q-abertas:** D-002, D-008, QP-002

### USP-010 — Cadastro de prestador de serviço (papel)

- **Upstream:** USP-001 ou USP-006, USP-043 (consentimento "oferta de serviço")
- **Downstream:** USP-029
- **ADRs:** ADR-0011, ADR-0013
- **Métricas:** MP3
- **Riscos:** RP-003
- **Deps/Q-abertas:** D-002

### USP-011 — Cadastro de cliente de serviço (papel)

- **Upstream:** USP-001 ou USP-006, USP-043 (consentimento "contratação de serviço")
- **Downstream:** USP-033
- **ADRs:** ADR-0011, ADR-0013
- **Métricas:** — (vetor para MP7)
- **Riscos:** RP-003
- **Deps/Q-abertas:** D-002

### USP-012 — Cadastro de Empresa (pela Pessoa que se torna responsável)

- **Upstream:** USP-001 (ou USP-006 ativando papel empresa-responsável), USP-043 (consentimento "representação de empresa")
- **Downstream:** USP-013, USP-014, USP-015, USP-017, USP-020, USP-029 (publicar serviço em nome de Empresa), USP-027
- **ADRs:** ADR-0011, ADR-0013, ADR-0014
- **Métricas:** MP2 (vetor — Empresa só vira "verificada" via USP-017)
- **Riscos:** RP-005 (empresa-fantasma — entrada do vetor)
- **Deps/Q-abertas:** D-002

### USP-013 — Adicionar responsável a uma Empresa

- **Upstream:** USP-012, USP-001 (Pessoa-alvo precisa estar pré-cadastrada — sem convite)
- **Downstream:** USP-014, USP-020, USP-029
- **ADRs:** ADR-0014, ADR-0017
- **Métricas:** —
- **Riscos:** Risco proposto: revelação inadvertida de existência de Pessoa via busca por CPF/e-mail (mitigado por design da UX — não revelar nome até confirmar; ❓ definir comportamento exato)
- **Deps/Q-abertas:** —

### USP-014 — Remover responsável de uma Empresa

- **Upstream:** USP-012, USP-013
- **Downstream:** USP-007 (sucessão de responsável quando Pessoa inativada)
- **ADRs:** ADR-0014
- **Métricas:** —
- **Riscos:** Risco proposto: Empresa órfã (mitigado por AC-014-2)
- **Deps/Q-abertas:** —

### USP-015 — Editar dados da Empresa

- **Upstream:** USP-012
- **Downstream:** USP-017 (re-verificação ao editar CNPJ/razão social/nome fantasia)
- **ADRs:** ADR-0014, ADR-0015
- **Métricas:** —
- **Riscos:** RP-005 (vetor pós-verificação — Empresa verificada edita dados e finge ainda estar verificada)
- **Deps/Q-abertas:** —

### USP-016 — Moderar rascunho (vaga, CV ou serviço)

- **Upstream:** USP-008 (permissão delegada de moderar), USP-020/USP-009/USP-029 (rascunho existe)
- **Downstream:** USP-021, USP-022, USP-028, USP-030, USP-031, USP-044
- **ADRs:** ADR-0001 (estendido), ADR-0015
- **Métricas:** MP10 (tempo médio de moderação)
- **Riscos:** RP-004 (carga de moderação), RP-005 (defesa, junto com USP-017), RP-010 (sem denúncia formal)
- **Deps/Q-abertas:** D-006

### USP-017 — Validar Empresa na primeira vaga publicada

- **Upstream:** USP-012 (Empresa "não verificada"), USP-020 (primeira vaga em moderação), USP-016 (fluxo de moderação)
- **Downstream:** USP-027, USP-028 (Empresa verificada aparece para candidatos)
- **ADRs:** ADR-0014, ADR-0015
- **Métricas:** MP2
- **Riscos:** RP-005 (principal defesa do MVP contra empresa-fantasma)
- **Deps/Q-abertas:** Q proposta: lista de verificação ("checklist") do coordenador — entregável da Fase 0

### USP-018 — Inativar conteúdo já publicado

- **Upstream:** USP-008 (permissão delegada), USP-016 (conteúdo aprovado previamente)
- **Downstream:** —
- **ADRs:** ADR-0015
- **Métricas:** —
- **Riscos:** RP-010 (escape válve para ausência de denúncia formal)
- **Deps/Q-abertas:** —

### USP-019 — Sugerir nova categoria de serviço ou área de vaga

- **Upstream:** USP-020 ou USP-029 (autor publicando)
- **Downstream:** USP-008 (permissão de aprovar sugestão)
- **ADRs:** ADR-0010
- **Métricas:** —
- **Riscos:** Risco proposto: catálogo poluído por sugestões fora de padrão (mitigado por aprovação humana)
- **Deps/Q-abertas:** D-007

### USP-020 — Publicar vaga

- **Upstream:** USP-012, USP-013 (a Pessoa precisa ser responsável da Empresa)
- **Downstream:** USP-016, USP-017 (se primeira vaga), USP-021, USP-022, USP-024, USP-027, USP-037
- **ADRs:** ADR-0014, ADR-0015
- **Métricas:** MP4
- **Riscos:** RP-005 (vetor de entrada de empresa-fantasma com vaga)
- **Deps/Q-abertas:** D-007

### USP-021 — Buscar vagas (pública)

- **Upstream:** USP-016 (vaga aprovada e ativa), USP-024 (vagas expiradas ocultas)
- **Downstream:** USP-022, USP-025
- **ADRs:** ADR-0015, ADR-0017
- **Métricas:** — (vetor de descoberta)
- **Riscos:** RP-009 (volume tráfego anônimo)
- **Deps/Q-abertas:** —

### USP-022 — Ver detalhe da vaga

- **Upstream:** USP-021
- **Downstream:** USP-025
- **ADRs:** ADR-0015, ADR-0017
- **Métricas:** —
- **Riscos:** RP-009
- **Deps/Q-abertas:** —

### USP-023 — Editar vaga (pausar, arquivar, renovar)

- **Upstream:** USP-020
- **Downstream:** USP-016 (edição volta a rascunho — re-moderação)
- **ADRs:** ADR-0015
- **Métricas:** —
- **Riscos:** Risco proposto: prorrogação sem re-moderação burla controle de qualidade de conteúdo já alterado (mitigado: prorrogação só de validade, AC-023-4)
- **Deps/Q-abertas:** —

### USP-024 — Expiração automática de vaga

- **Upstream:** USP-020 (vaga com data de validade)
- **Downstream:** USP-021 (vagas expiradas ocultas)
- **ADRs:** ADR-0010, ADR-0015
- **Métricas:** —
- **Riscos:** Risco proposto: job de expiração falha silenciosamente; vaga vencida fica visível (precisa de observabilidade)
- **Deps/Q-abertas:** —

### USP-025 — Candidatar-se a uma vaga

- **Upstream:** USP-009 (perfil ativo do candidato), USP-021/USP-022 (vaga ativa), USP-043
- **Downstream:** USP-026, USP-027, USP-044
- **ADRs:** ADR-0013, ADR-0017
- **Métricas:** MP6
- **Riscos:** RP-008 indireto (CV processado por IA aparece na empresa)
- **Deps/Q-abertas:** D-002

### USP-026 — Cancelar candidatura

- **Upstream:** USP-025
- **Downstream:** USP-025 (re-candidatura permitida)
- **ADRs:** ADR-0017
- **Métricas:** —
- **Riscos:** —
- **Deps/Q-abertas:** —

### USP-027 — Empresa ver lista de candidatos da vaga

- **Upstream:** USP-025, USP-037 (candidatura encaminhada com badge)
- **Downstream:** —
- **ADRs:** ADR-0014, ADR-0016 (badge), ADR-0017
- **Métricas:** MP6 (indireto)
- **Riscos:** RP-008 (CV processado por IA aparece com qualidade questionável)
- **Deps/Q-abertas:** —

### USP-028 — Empresa buscar candidatos (busca ativa)

- **Upstream:** USP-009 (candidatos com perfil ativo), USP-012 (Empresa autenticada)
- **Downstream:** USP-025 (Empresa pode atrair candidatura)
- **ADRs:** ADR-0014, ADR-0017
- **Métricas:** —
- **Riscos:** Risco proposto: mineração de dados de candidatos (mitigado por ADR-0017 — campos sensíveis ocultos até candidatura)
- **Deps/Q-abertas:** —

### USP-029 — Publicar serviço

- **Upstream:** USP-010 (papel prestador PF) OU USP-012 (Empresa) + USP-013, USP-043
- **Downstream:** USP-016, USP-030, USP-031, USP-032, USP-033, USP-035
- **ADRs:** ADR-0014, ADR-0015
- **Métricas:** MP5
- **Riscos:** Risco proposto: serviço ilegal ou enganoso publicado (mitigado por moderação USP-016)
- **Deps/Q-abertas:** D-002, D-007

### USP-030 — Buscar serviços (pública)

- **Upstream:** USP-016 (serviço aprovado)
- **Downstream:** USP-031, USP-033
- **ADRs:** ADR-0015, ADR-0017
- **Métricas:** — (vetor de descoberta)
- **Riscos:** RP-009
- **Deps/Q-abertas:** —

### USP-031 — Ver detalhe do serviço

- **Upstream:** USP-030
- **Downstream:** USP-033
- **ADRs:** ADR-0017
- **Métricas:** —
- **Riscos:** RP-009
- **Deps/Q-abertas:** —

### USP-032 — Editar serviço (pausar, arquivar)

- **Upstream:** USP-029
- **Downstream:** USP-016 (edição volta a rascunho)
- **ADRs:** ADR-0015
- **Métricas:** —
- **Riscos:** —
- **Deps/Q-abertas:** —

### USP-033 — Manifestar interesse em serviço

- **Upstream:** USP-001 ou USP-006, USP-011 (papel cliente — ativado automaticamente), USP-030/USP-031, USP-043
- **Downstream:** USP-034, USP-035, USP-044
- **ADRs:** ADR-0011, ADR-0013, ADR-0017
- **Métricas:** MP7
- **Riscos:** RP-003 (consentimento da finalidade "contratação de serviço")
- **Deps/Q-abertas:** D-002

### USP-034 — Cancelar manifestação de interesse

- **Upstream:** USP-033
- **Downstream:** —
- **ADRs:** ADR-0017
- **Métricas:** —
- **Riscos:** —
- **Deps/Q-abertas:** —

### USP-035 — Prestador ver manifestações de interesse

- **Upstream:** USP-033
- **Downstream:** —
- **ADRs:** ADR-0017
- **Métricas:** MP7 (indireto)
- **Riscos:** —
- **Deps/Q-abertas:** —

### USP-036 — Cadastrar ficha socioeconômica da Pessoa

- **Upstream:** USP-001 ou USP-002 (Pessoa existe), USP-043 (consentimento "atendimento social")
- **Downstream:** USP-037, USP-039
- **ADRs:** ADR-0011, ADR-0012, ADR-0013, ADR-0017 (acesso restrito a AS e diretoria)
- **Métricas:** —
- **Riscos:** RP-002 (DPO), RP-003 (termo de atendimento social)
- **Deps/Q-abertas:** D-001, D-002

### USP-037 — Encaminhar Pessoa para vaga

- **Upstream:** USP-001 ou USP-002 (Pessoa existe), USP-020 (vaga ativa), USP-008 (permissão delegada para encaminhar), USP-043 (consentimento "encaminhamento institucional")
- **Downstream:** USP-027 (badge), USP-038, USP-039, USP-044
- **ADRs:** ADR-0001, ADR-0011, ADR-0013, ADR-0016, ADR-0017
- **Métricas:** MP8
- **Riscos:** RP-002, RP-003 (sem aceite prévio da Pessoa — termo precisa cobrir)
- **Deps/Q-abertas:** D-001, D-002

### USP-038 — Registrar resultado do encaminhamento manualmente

- **Upstream:** USP-037, USP-008 (permissão)
- **Downstream:** USP-039
- **ADRs:** ADR-0016
- **Métricas:** MP9
- **Riscos:** Risco proposto: viés de registro (só o sucesso é registrado, métrica MP9 fica inflada)
- **Deps/Q-abertas:** —

### USP-039 — Visão consolidada da Pessoa

- **Upstream:** USP-001, USP-009, USP-010, USP-011, USP-012, USP-025, USP-029, USP-033, USP-036, USP-037, USP-038
- **Downstream:** —
- **ADRs:** ADR-0008, ADR-0011, ADR-0016, ADR-0017
- **Métricas:** — (instrumento de gestão, não vetor de métrica direta)
- **Riscos:** RP-002 (sem DPO, acesso amplo a dado sensível é desconfortável); risco proposto: visão consolidada exposta acidentalmente a usuário não autorizado
- **Deps/Q-abertas:** D-001

### USP-040 — Extração automática de CV via IA generativa

- **Upstream:** USP-009 (candidato anexa CV), USP-043 (consentimento "extração via IA")
- **Downstream:** USP-009 (pré-preenche), USP-025 (CV processado aparece na candidatura)
- **ADRs:** ADR-0010 (custo da API LLM), ADR-0013 (finalidade 7), ADR-0018
- **Métricas:** MP1 (acelera ativação de candidato)
- **Riscos:** RP-007 (CV ruim validado), RP-008 (LLM sem ZDR), RP-003 (termo cobrindo IA)
- **Deps/Q-abertas:** D-002, D-008, QP-002

### USP-041 — Home pública com indicadores em tempo real

- **Upstream:** USP-009 (candidatos ativos), USP-012+USP-017 (empresas verificadas), USP-020+USP-016 (vagas ativas)
- **Downstream:** —
- **ADRs:** ADR-0010, ADR-0017 (indicadores são agregados — sem dado pessoal)
- **Métricas:** — (instrumento de comunicação)
- **Riscos:** RP-009 (cache crítico)
- **Deps/Q-abertas:** D-012, QP-004

### USP-042 — Relatórios operacionais do Portal

- **Upstream:** todas as USPs operacionais (vagas, candidaturas, serviços, encaminhamentos, moderação)
- **Downstream:** —
- **ADRs:** ADR-0008, ADR-0017
- **Métricas:** MP1–MP10 (consolidação para gestão e prestação de contas)
- **Riscos:** RP-002 (relatórios com dado pessoal sem DPO designado)
- **Deps/Q-abertas:** D-001, D-005, QP-005

### USP-043 — Consentimentos LGPD por finalidade

- **Upstream:** —
- **Downstream:** USP-001, USP-006, USP-009, USP-010, USP-011, USP-012, USP-025, USP-033, USP-036, USP-037, USP-040 (toda ativação de papel ou finalidade nova)
- **ADRs:** ADR-0008 (retenção do registro de consentimento), ADR-0013
- **Métricas:** — (transversal)
- **Riscos:** RP-002, RP-003 (depende dos termos por finalidade)
- **Deps/Q-abertas:** D-001, D-002

### USP-044 — Notificações por e-mail em eventos do portal

- **Upstream:** USP-001 (boas-vindas), USP-005 (recuperação de senha), USP-016 (decisão de moderação), USP-025 (confirmação candidatura), USP-033 (manifestação), USP-037 (encaminhamento), USP-024 (expiração próxima), USP-009 (lembrete de CV desatualizado)
- **Downstream:** —
- **ADRs:** ADR-0010 (custo do provedor SMTP)
- **Métricas:** — (transversal)
- **Riscos:** Risco proposto: e-mails caem em spam (mitigado por SPF/DKIM/DMARC — decisão técnica do Arquiteto); risco proposto: vazamento de dado pessoal em corpo de e-mail mal projetado
- **Deps/Q-abertas:** —

---

## Seção 3 — Lookups inversos

### 3.1 ADR → USPs

| ADR | Título | USPs que referenciam |
|---|---|---|
| ADR-0001 | Delegação granular de permissões (estendido para Portal) | USP-008, USP-016, USP-017, USP-018, USP-019, USP-037, USP-038 |
| ADR-0008 | Retenção indefinida e direito de acesso (estendido) | USP-007, USP-036, USP-039, USP-042, USP-043 |
| ADR-0010 | Custo mínimo como diretriz arquitetural | USP-001, USP-002, USP-003, USP-004, USP-005, USP-007, USP-008, USP-019, USP-024, USP-040, USP-041, USP-044 (transversal — toda USP herda) |
| ADR-0011 | Pessoa como entidade fundamental, login único e papéis compostos | USP-001, USP-002, USP-003, USP-006, USP-007, USP-009, USP-010, USP-011, USP-012, USP-033, USP-036, USP-037, USP-039, USP-043 |
| ADR-0012 | Beneficiário como papel social da Pessoa | USP-036 |
| ADR-0013 | Consentimentos LGPD por finalidade | USP-001, USP-006, USP-009, USP-010, USP-011, USP-012, USP-025, USP-033, USP-036, USP-037, USP-040, USP-043 |
| ADR-0014 | Empresa sem login próprio, com Pessoas-responsáveis (N:N) | USP-012, USP-013, USP-014, USP-015, USP-017, USP-020, USP-027, USP-028, USP-029 |
| ADR-0015 | Moderação humana pré-publicação | USP-009, USP-015, USP-016, USP-017, USP-018, USP-020, USP-021, USP-022, USP-023, USP-024, USP-029, USP-030, USP-031, USP-032 |
| ADR-0016 | Encaminhamento como entidade do domínio social | USP-027, USP-037, USP-038, USP-039 |
| ADR-0017 | Visibilidade conservadora de dados pessoais entre papéis | USP-001, USP-002, USP-003, USP-013, USP-021, USP-022, USP-025, USP-026, USP-027, USP-028, USP-030, USP-031, USP-033, USP-034, USP-035, USP-036, USP-039, USP-041, USP-042 |
| ADR-0018 | Extração de CV via IA generativa | USP-009, USP-040 |

### 3.2 Risco → USPs

| Risco | USPs vetoras |
|---|---|
| RP-001 — Escopo > orçamento | Meta-risco; sem USP-vetor (acompanhamento via processo de estimativa fina) |
| RP-002 — DPO não designado a tempo | USP-036, USP-037, USP-039, USP-042, USP-043; bloqueia também USP-007 (atender pedido de inativação por titular) |
| RP-003 — Termos de consentimento por finalidade não revisados a tempo | USP-001, USP-006, USP-009, USP-010, USP-011, USP-012, USP-025, USP-033, USP-036, USP-037, USP-040, USP-043 |
| RP-004 — Carga de moderação inviabiliza operação | USP-016 (principal), USP-008 (mitigação via delegação) |
| RP-005 — Empresa-fantasma escapa da moderação manual | USP-012 (entrada), USP-015 (vetor pós-verificação), USP-017 (defesa principal), USP-020 |
| RP-006 — Adesão baixa | Meta-risco; sem USP-vetor direta |
| RP-007 — Extração de CV gera dados ruins e candidato valida sem revisar | USP-040 (principal), USP-009 (pré-preenchimento), USP-025/USP-027 (efeito visível para Empresa) |
| RP-008 — Uso de LLM com retenção inadequada afeta LGPD | USP-040 (principal), USP-009 (indireto) |
| RP-009 — Volume de tráfego anônimo excede expectativa em pico | USP-021, USP-022, USP-030, USP-031, USP-041 |
| RP-010 — Ausência de fluxo formal de denúncia atrasa resposta | USP-018 (escape válve), USP-016 (modo proativo) |
| RP-011 — Sponsor não designado a tempo do kickoff | Meta-risco |

### 3.3 Dependência → USPs (em produção)

| Dep | Owner | USPs bloqueadas |
|---|---|---|
| D-001 — Designação formal do DPO | Diretoria ASONSEG | USP-036, USP-037, USP-039, USP-042, USP-043 |
| D-002 — Termos de consentimento por finalidade e revisão jurídica | Diretoria + jurídico | USP-001, USP-006, USP-009, USP-010, USP-011, USP-012, USP-025, USP-033, USP-036, USP-037, USP-040, USP-043 |
| D-003 — Designação do sponsor | Diretoria ASONSEG | Bloqueante de kickoff — sem USP específica |
| D-004 — Metas concretas para MP1–MP10 | Sponsor + Bravi PO | Não bloqueia código; bloqueia avaliação de sucesso |
| D-005 — Refinamento de filtros/agrupamentos dos relatórios | Bravi PO + diretoria | USP-042 |
| D-006 — Revisão final do catálogo de permissões delegáveis | Bravi PO + coordenador | USP-008 |
| D-007 — Cadastro inicial de categorias/áreas/regiões | Diretoria ASONSEG | USP-019, USP-020, USP-029 |
| D-008 — Escolha do provedor de IA generativa | Bravi Arquiteto | USP-040 |
| D-009 — Escolha do provedor de CAPTCHA | Bravi Arquiteto | USP-001 |
| D-010 — Estimativa fina pelo Tech Lead | Bravi Tech Lead | Bloqueante de orçamento — sem USP específica |
| D-011 — Meios de verificação para reivindicação de credencial | Diretoria + Bravi PO | USP-003 |
| D-012 — Política de cache dos indicadores em tempo real | Bravi Arquiteto | USP-041 |

### 3.4 Q-aberta → USPs

| Q-aberta | USPs afetadas |
|---|---|
| QP-001 — Meios de verificação para reivindicação | USP-003 |
| QP-002 — Provedor IA | USP-009, USP-040 |
| QP-003 — Provedor CAPTCHA | USP-001 |
| QP-004 — Política de cache | USP-041 |
| QP-005 — Detalhamento dos relatórios | USP-042 |
| QP-006 — Revisão final do catálogo de permissões | USP-008 |
| QP-007 — Metas MP1–MP10 | USP-009, USP-012, USP-016, USP-025, USP-029, USP-033, USP-037, USP-038 (toda USP que vetoriza métrica) |
| QP-008 — Política de retenção de logs operacionais | USP-042 (indireto); transversal |
| QP-009 — Estratégia de divulgação inicial | USP-021, USP-030, USP-041 (carga de tráfego) |
| QP-010 — Lista inicial de regiões/categorias/áreas | USP-019, USP-020, USP-029 |

### 3.5 Métrica → USPs

| Métrica | USPs que contribuem |
|---|---|
| MP1 — Candidatos com perfil ativo (moderado) | USP-001 (entrada), USP-006, USP-009 (principal), USP-016 (aprova), USP-040 (acelera) |
| MP2 — Empresas verificadas | USP-001 (entrada), USP-006, USP-012 (entrada), USP-017 (verifica) |
| MP3 — Prestadores ativos com ≥ 1 serviço aprovado | USP-001, USP-006, USP-010, USP-016 (aprova serviço), USP-029 |
| MP4 — Vagas publicadas e aprovadas | USP-020 (publica), USP-016 (aprova) |
| MP5 — Serviços publicados e aprovados | USP-029, USP-016 |
| MP6 — Candidaturas realizadas | USP-025 |
| MP7 — Manifestações de interesse em serviços | USP-033, USP-035 (indireto) |
| MP8 — Encaminhamentos ASONSEG criados | USP-037 |
| MP9 — % de encaminhamentos com resultado positivo registrado | USP-038 |
| MP10 — Tempo médio de moderação | USP-016 |

---

## Seção 4 — Views derivadas

### 4.1 USPs de alta concentração de risco

USPs que tocam ≥ 3 ADRs **ou** ≥ 2 riscos **ou** ≥ 2 dependências bloqueantes. Onde priorizar análise prévia (gate humano denso na revisão).

| USP | Razão da alta concentração |
|---|---|
| USP-001 | 4 ADRs (0010, 0011, 0013, 0017); 2 riscos (RP-003, RP-008 indireto); 2 deps (D-002, D-009) |
| USP-009 | 5 ADRs (0011, 0013, 0015, 0017, 0018); 3 riscos (RP-003, RP-007, RP-008); 2 deps (D-002, D-008) |
| USP-012 | 3 ADRs (0011, 0013, 0014); 1 risco crítico (RP-005); 1 dep (D-002) |
| USP-016 | 2 ADRs (0001, 0015); 3 riscos (RP-004, RP-005, RP-010); 1 dep (D-006) |
| USP-017 | 2 ADRs (0014, 0015); 1 risco crítico principal (RP-005) |
| USP-020 | 2 ADRs (0014, 0015); 1 risco crítico (RP-005); 1 dep (D-007) |
| USP-036 | 4 ADRs (0011, 0012, 0013, 0017); 2 riscos (RP-002, RP-003); 2 deps (D-001, D-002) |
| USP-037 | 5 ADRs (0001, 0011, 0013, 0016, 0017); 2 riscos (RP-002, RP-003); 2 deps (D-001, D-002) |
| USP-039 | 4 ADRs (0008, 0011, 0016, 0017); 1 risco (RP-002); 1 dep (D-001) |
| USP-040 | 3 ADRs (0010, 0013, 0018); 3 riscos (RP-003, RP-007, RP-008); 2 deps (D-002, D-008) |
| USP-042 | 2 ADRs (0008, 0017); 1 risco (RP-002); 3 deps (D-001, D-005, QP-005) |
| USP-043 | 2 ADRs (0008, 0013); 2 riscos (RP-002, RP-003); 2 deps (D-001, D-002) |

### 4.2 USPs fundacionais

Quem é upstream de muita coisa — mexer dói. Mudança de design dessas USPs tem alto blast radius.

| USP | Por que é fundacional |
|---|---|
| USP-001 | Entrada de qualquer Pessoa pública — porta única do sistema |
| USP-004 | Sem login, nenhuma USP autenticada existe |
| USP-008 | Sem delegação de permissões, USP-016/USP-017/USP-018/USP-037 viram gargalo no coordenador |
| USP-012 | Sem Empresa, não há vaga, busca de candidato, serviço por PJ |
| USP-016 | Sem moderação, conteúdo não chega a ser ativo — bloqueia visibilidade de tudo |
| USP-043 | Sem consentimento por finalidade, nenhum papel pode ser ativado sob LGPD |

### 4.3 USPs bloqueadas em produção por decisão pendente (gate humano)

USPs cujo expectations file marca gate explícito — código pronto não basta. Lista mais útil para sponsor.

| USP | Gate | Responsável |
|---|---|---|
| USP-001 | D-002 (termo "cadastro e autenticação") + D-009 (CAPTCHA) | Diretoria + jurídico + Arquiteto |
| USP-003 | D-011 + QP-001 | Diretoria + AS + Bravi PO |
| USP-009 | D-002 (termo "candidatura a vagas") | Diretoria + jurídico |
| USP-010 | D-002 (termo "oferta de serviço") | Diretoria + jurídico |
| USP-011 | D-002 (termo "contratação de serviço") | Diretoria + jurídico |
| USP-012 | D-002 (termo "representação de empresa") | Diretoria + jurídico |
| USP-017 | Checklist de verificação de Empresa (entregável Fase 0) | Coordenador do Portal + Bravi PO |
| USP-033 | D-002 (termo "contratação de serviço") | Diretoria + jurídico |
| USP-036 | D-001 (DPO) + D-002 (termo "atendimento social") | Diretoria |
| USP-037 | D-001 (DPO) + D-002 (termo "encaminhamento institucional" cobrindo finalidade 8 do ADR-0013) | Diretoria + jurídico |
| USP-039 | D-001 (DPO) | Diretoria |
| USP-040 | D-002 (termo "extração via IA") + D-008 (provedor com ZDR confirmado) + QP-002 | Diretoria + jurídico + Arquiteto |
| USP-042 | D-001 (DPO) + D-005 (refinamento dos relatórios) | Diretoria + Bravi PO |
| USP-043 | D-001 (DPO) + D-002 (todos os termos) | Diretoria + jurídico |

---

## Notas finais sobre a matriz

Esta matriz é **esquelética**: cobre tudo o que o PRD do PO já define — USPs, ADRs de negócio, métricas, riscos, dependências, Q-abertas — e as relações entre eles. As colunas técnicas (schemas de dados, skills/runbooks de operação, ADRs técnicos do Arquiteto, decisões de stack, ambiente de homologação) **serão preenchidas pela skill `architecture-planning`** a partir desta matriz, antes do dev per-US começar.

Riscos marcados como "(proposto)" no corpo da matriz e não constantes do §13 do PRD precisam de validação no próximo CHANGELOG do PRD (v0.4). O mesmo vale para a observação sobre USP-004 (ACs não explícitos no PRD na §5.2).
